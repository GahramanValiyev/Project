# BRAINNEST WEEK 3 - PROJECT

- inside this directory there are 2 files index.html and script.js
- html file is empty (it only has import of js file)
- js file is only using prompt and console for output and input (no DOM connection at all)
